/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evidenciafinalvero;

import com.restfb.Connection;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.types.FacebookType;
import com.restfb.types.Post;
import com.restfb.types.User;
import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Verónica Rodríguez
 */
public class EvidenciaFinalVero {

    /**
     * @param args the command line arguments
     */
    
    public static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int num;
        String respuesta;

        do {
            do {
                System.out.println("Ingresa el número de la opción que quiera utilizar \n " +
                        "1 = Ver tu nombre \n " +
                        "2 = Ver tus posts/links \n " +
                        "3 = Ver los posts de tus amigos \n " +
                        "4 = Publicar estado \n" +
                        " 5 = Publicar link ");

                num = sc.nextInt();

            } while (num > 4 || num < 1);
            if (num == 1) {
                name();
            }
            if (num == 2) {
                seePosts();
            } 
           if (num == 3) {
               seeFriendPosts();
            }
           if (num == 4) {
               publishStatus();
            }
           if (num == 5) {
               publishLink();
            }

            // Salir o vovler a intentar

            System.out.println("¿Deseas hacer alguna otra cosa?: \n " +
                    "y = Sí \n " +
                    "n = No");
            sc.nextLine();
            respuesta = sc.nextLine();

        } while (respuesta.equalsIgnoreCase("y"));
    }
    
// Facebook stuff: 
    
//Nombre (Esta función solo era una prueba paraver que todo estuviera conectado)
    public static void name() {
        String accessToken = "EAACZBiVtsfFsBAIBI3VWEEpid8rKiczkoS52QOIJUM56gGl1iXWk5JmUpFhSOLsR5C8lCAwHRui0iKRGHrz3zjQ7WYWX7FvOiwSWoXZAmpMLXbgnFCXeZCNs2EgT8jbTlwt0SwzH09RpF1n48LqZBIehCnHjdinzPBDdBwu7hyYkjdtxtmM2ij2p0tF0RVAigLi4VBKdWPbeZCTJmxsNyhyR0yGMfUsE5cpyCZBjuvxQZDZD";
        FacebookClient fbClient = (FacebookClient) new DefaultFacebookClient(accessToken);
        User me = fbClient.fetchObject("me", User.class);
        
        System.out.println(me.getName()); 
    }

//  Ver tus propios Posts
     public static void seePosts() {
        String accessToken = "EAACZBiVtsfFsBAIBI3VWEEpid8rKiczkoS52QOIJUM56gGl1iXWk5JmUpFhSOLsR5C8lCAwHRui0iKRGHrz3zjQ7WYWX7FvOiwSWoXZAmpMLXbgnFCXeZCNs2EgT8jbTlwt0SwzH09RpF1n48LqZBIehCnHjdinzPBDdBwu7hyYkjdtxtmM2ij2p0tF0RVAigLi4VBKdWPbeZCTJmxsNyhyR0yGMfUsE5cpyCZBjuvxQZDZD";
        FacebookClient fbClient = (FacebookClient) new DefaultFacebookClient(accessToken);
        Connection<Post> result = fbClient.fetchConnection("me/feed", Post.class);
        
        int i = 0; 
        for(List<Post> page : result){
            for (Post aPost : page){
                System.out.println(aPost.getMessage()); 
                System.out.println("fb.com/" + aPost.getId());
                i++;
            }
        }
        System.out.println("No. of  Results: " + i);
       
    }

/* Ver Posts de tus amigos (Esta función no funciona porque Facebook no ha autorizado mi app y 
no tengo acceso a este permiso de la API) */
     public static void seeFriendPosts() {
        String accessToken = "EAACZBiVtsfFsBAIBI3VWEEpid8rKiczkoS52QOIJUM56gGl1iXWk5JmUpFhSOLsR5C8lCAwHRui0iKRGHrz3zjQ7WYWX7FvOiwSWoXZAmpMLXbgnFCXeZCNs2EgT8jbTlwt0SwzH09RpF1n48LqZBIehCnHjdinzPBDdBwu7hyYkjdtxtmM2ij2p0tF0RVAigLi4VBKdWPbeZCTJmxsNyhyR0yGMfUsE5cpyCZBjuvxQZDZD";
        FacebookClient fbClient = (FacebookClient) new DefaultFacebookClient(accessToken);
        Connection<Post> result = fbClient.fetchConnection("me/home", Post.class);
        
        int i = 0; 
        for(List<Post> page : result){
            for (Post aPost : page){
                System.out.println(aPost.getMessage()); 
                System.out.println("fb.com/" + aPost.getId());
                i++;
            }
        }
        System.out.println("No. of  Results: " + i);
       
    }

//  Publicar Estado (Esta función no funciona porque Facebook no me ha autorizado los permisos)
     public static void publishStatus() {
        String accessToken = "EAACZBiVtsfFsBAFtSaOySVGlrv45O7Jbk8uM8oZAFg68tH6SlRtTjZAk6ZBm5pjXvL7CwLZCArAdsoA4zI6onrWoxlkdZAE5vAkToSAwGh8ZAR1iGi1mil3IpZBPVqXFuQZA8w70zGN7NaFm793syZAEZChM2xZCSD3IbDZCP3b0EjJlUK5Agi2LXOfSocRbvZBNbJImDfNPXVhfPCxgZDZD";
        FacebookClient fbClient = (FacebookClient) new DefaultFacebookClient(accessToken);
        FacebookType response = fbClient.publish("me/feed", FacebookType.class, Parameter.with("message", "This is a smol Java Graph API test."));
        System.out.println("fb.com/" + response.getId());
    } 
     
//  Publicar Link (Esta función no funciona porque Facebook no me ha autorizado los permisos)
     public static void publishLink() {
        String accessToken = "EAACZBiVtsfFsBAIBI3VWEEpid8rKiczkoS52QOIJUM56gGl1iXWk5JmUpFhSOLsR5C8lCAwHRui0iKRGHrz3zjQ7WYWX7FvOiwSWoXZAmpMLXbgnFCXeZCNs2EgT8jbTlwt0SwzH09RpF1n48LqZBIehCnHjdinzPBDdBwu7hyYkjdtxtmM2ij2p0tF0RVAigLi4VBKdWPbeZCTJmxsNyhyR0yGMfUsE5cpyCZBjuvxQZDZD";
        FacebookClient fbClient = (FacebookClient) new DefaultFacebookClient(accessToken);
        FacebookType response = fbClient.publish("me/feed", FacebookType.class, Parameter.with("message", "This is another smol Java Graph API Link test."), Parameter.with("link", "https://google.com"));
        System.out.println("db.com/" + response.getId());
    }
}